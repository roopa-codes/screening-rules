# Screening Rules API

A Spring Boot REST API for creating application forms and attaching screening rules to form questions. Jobs select a form; they do not own a separate copy of the form's rules.

## Requirements

- Java 17
- Maven
- PostgreSQL with the application schema already created

The supplied schema must already be present, including the `forms`, `questions`, `form_questions`, `jobs`, `rule_types`, `rule_set_versions`, `rules`, and `audit_logs` tables. On startup, Flyway adds form ownership to rule-set versions and links existing rules to the form used by their job; existing rule-set versions remain job-owned. New rules are stored in form-owned rule-set versions. Add supported rule type codes to `rule_types` before creating rules.

## Configuration

Set these environment variables before starting the application:

| Variable | Description |
| --- | --- |
| `DATABASE_URL` | JDBC URL, for example `jdbc:postgresql://localhost:5432/screening` |
| `DATABASE_USERNAME` | Database user |
| `DATABASE_PASSWORD` | Database password |

## Run

```shell
mvn spring-boot:run
```

The API listens on port `8080` by default.

## Endpoints

### Create a job using a form

`POST /api/jobs`

```json
{
  "title": "Pharmacist - Hyderabad",
  "formId": 1,
  "createdBy": 1
}
```

The job references the selected form through `jobs.form_id`. Its questions and screening rules are defined on that form, so callers do not send or copy rules while creating the job.

### Create a form

`POST /api/forms`

```json
{
  "name": "Pharmacist application",
  "questions": [
    {
      "questionKey": "location",
      "label": "What is your location?",
      "answerType": "SINGLE_SELECT",
      "required": true,
      "options": ["Hyderabad", "Secunderabad"]
    },
    {
      "questionKey": "experience",
      "label": "Years of experience",
      "answerType": "NUMBER",
      "required": true
    },
    {
      "questionKey": "license",
      "label": "Do you hold a pharmacy license?",
      "answerType": "BOOLEAN",
      "required": true
    }
  ]
}
```

The API creates a `forms` row, stores or reuses each `questions` definition by its unique `question_key`, and links the questions through `form_questions` with their order and required flag. Reusing an existing question key is allowed only if its label, answer type, and options match. The operation and audit log entry are transactional.

### Add a rule to a question on a form

`POST /api/forms/{formId}/rules`

```json
{
  "ruleCode": "R1",
  "questionKey": "location",
  "ruleTypeCode": "ALLOWED_VALUES",
  "params": {
    "allowed": ["Hyderabad", "Secunderabad"]
  },
  "onFail": "FAIL",
  "onMissing": "REVIEW",
  "createdBy": 1
}
```

The `formId` must identify an existing form. `questionKey` must identify a question linked to that form, and `ruleTypeCode` must already exist in `rule_types`. The rule is stored against that question and in the form's latest `DRAFT` rule-set version; a draft is created if needed. The database enforces that the rule's form and question are linked. `onFail` and `onMissing` accept `FAIL` or `REVIEW`; omitted `onMissing` defaults to `REVIEW`.

### List rules for a form

`GET /api/forms/{formId}/rules`

Returns the rules in the form's latest draft rule-set version, including the question key each rule checks. A job can select the form through `jobs.form_id`; its screening rules are consequently the rules configured for that form.

The shape of `params` is rule-type-specific and must be agreed upon for each value in `rule_types`. Currently the API checks that `params` is present but does not validate its structure against the rule type.

## Current scope

This API creates forms and rules. Applicant answer submission, screening evaluation, recruiter overrides, publishing rule versions, and request idempotency are not implemented yet. Create requests are not idempotent: retrying form creation creates a new form, while repeating a rule code in a draft version returns a conflict.

## Tests

```shell
mvn test
```
