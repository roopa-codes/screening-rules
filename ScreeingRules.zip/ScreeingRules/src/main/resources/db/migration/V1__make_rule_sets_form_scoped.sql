ALTER TABLE rule_set_versions
    ADD COLUMN form_id bigint;

ALTER TABLE rule_set_versions
    ALTER COLUMN job_id DROP NOT NULL,
    ADD CONSTRAINT fk_rule_set_versions_form
        FOREIGN KEY (form_id) REFERENCES forms (id),
    ADD CONSTRAINT chk_rule_set_versions_owner
        CHECK (
            (job_id IS NOT NULL AND form_id IS NULL)
            OR (job_id IS NULL AND form_id IS NOT NULL)
        );

CREATE UNIQUE INDEX uq_rule_set_versions_form_version
    ON rule_set_versions (form_id, version_no)
    WHERE form_id IS NOT NULL;

CREATE INDEX idx_rule_set_versions_form_status
    ON rule_set_versions (form_id, status);

ALTER TABLE rules
    ADD COLUMN form_id bigint;

UPDATE rules r
SET form_id = jobs.form_id
FROM rule_set_versions rsv
JOIN jobs ON jobs.id = rsv.job_id
WHERE r.rule_set_version_id = rsv.id;

ALTER TABLE rules
    ALTER COLUMN form_id SET NOT NULL,
    ADD CONSTRAINT fk_rules_form_question
        FOREIGN KEY (form_id, question_id)
        REFERENCES form_questions (form_id, question_id);

CREATE INDEX idx_rules_form_id
    ON rules (form_id);
