package org.example.controller;

import org.example.model.CreateFormRequest;
import org.example.model.FormResponse;
import org.example.service.FormService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/forms")
public class FormController {
    private final FormService formService;

    public FormController(FormService formService) {
        this.formService = formService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FormResponse createForm(@RequestBody CreateFormRequest request) {
        return formService.createForm(request);
    }
//
//    POST /api/forms
//    Content-Type: application/json
//    Example request:
//    {
//        "name": "Pharmacist application",
//            "questions": [
//        {
//            "questionKey": "location",
//                "label": "Which city are you based in?",
//                "answerType": "SINGLE_SELECT",
//                "required": true,
//                "options": ["Hyderabad", "Secunderabad", "Pune"]
//        },
//        {
//            "questionKey": "experience",
//                "label": "How many years of pharmacy experience do you have?",
//                "answerType": "NUMBER",
//                "required": true
//        },
//        {
//            "questionKey": "has_license",
//                "label": "Do you hold a valid pharmacy license?",
//                "answerType": "BOOLEAN",
//                "required": true
//        }
//  ]
//    }
}
