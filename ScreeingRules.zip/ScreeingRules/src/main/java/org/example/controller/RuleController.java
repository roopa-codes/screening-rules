package org.example.controller;

import org.example.model.CreateRuleRequest;
import org.example.model.RuleResponse;
import org.example.service.RuleService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/forms/{formId}/rules")
public class RuleController {
    private final RuleService ruleService;

    public RuleController(RuleService ruleService) {
        this.ruleService = ruleService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RuleResponse createRule(
            @PathVariable("formId") long formId,
            @RequestBody CreateRuleRequest request
    ) {
        return ruleService.createRule(formId, request);
    }

    @GetMapping
    public List<RuleResponse> listRules(@PathVariable("formId") long formId) {
        return ruleService.listRules(formId);
    }

//    POST /api/forms/1/rules
//    Content-Type: application/json
//    Example: location must be Hyderabad or Secunderabad
//    {
//        "ruleCode": "R1",
//            "questionKey": "location",
//            "ruleTypeCode": "ALLOWED_VALUES",
//            "params": {
//        "allowed": ["Hyderabad", "Secunderabad"]
//    },
//        "onFail": "FAIL",
//            "onMissing": "REVIEW",
//            "createdBy": 1
//    }
//    Example: experience must be at least 3 years
//    {
//        "ruleCode": "R2",
//            "questionKey": "experience",
//            "ruleTypeCode": "MINIMUM",
//            "params": {
//        "minimum": 3
//    },
//        "onFail": "REVIEW",
//            "onMissing": "REVIEW",
//            "createdBy": 1
//    }
}
