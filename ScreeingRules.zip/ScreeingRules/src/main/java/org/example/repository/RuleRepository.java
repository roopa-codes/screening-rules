package org.example.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.model.RuleResponse;
import org.example.model.RuleSetVersionRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RuleRepository {
    private final JdbcTemplate jdbc;
    private final ObjectMapper objectMapper;

    public RuleRepository(JdbcTemplate jdbc, ObjectMapper objectMapper) {
        this.jdbc = jdbc;
        this.objectMapper = objectMapper;
    }

    public boolean lockForm(long formId) {
        List<Long> formIds = jdbc.query(
                "SELECT id FROM forms WHERE id = ? FOR UPDATE",
                (resultSet, rowNum) -> resultSet.getLong("id"),
                formId
        );
        return !formIds.isEmpty();
    }

    public Long findQuestionIdOnForm(long formId, String questionKey) {
        List<Long> questionIds = jdbc.query(
                """
                SELECT q.id
                FROM questions q
                JOIN form_questions fq ON fq.question_id = q.id
                WHERE fq.form_id = ? AND q.question_key = ?
                """,
                (resultSet, rowNum) -> resultSet.getLong("id"),
                formId,
                questionKey
        );
        return questionIds.stream().findFirst().orElse(null);
    }

    public boolean ruleTypeExists(String ruleTypeCode) {
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM rule_types WHERE code = ?",
                Integer.class,
                ruleTypeCode
        );
        return count != null && count > 0;
    }

    public RuleSetVersionRecord findDraftRuleSet(long formId) {
        List<RuleSetVersionRecord> drafts = jdbc.query(
                """
                SELECT id, version_no
                FROM rule_set_versions
                WHERE form_id = ? AND status = 'DRAFT'
                ORDER BY version_no DESC
                LIMIT 1
                """,
                (resultSet, rowNum) -> new RuleSetVersionRecord(
                        resultSet.getLong("id"),
                        resultSet.getInt("version_no")
                ),
                formId
        );
        return drafts.stream().findFirst().orElse(null);
    }

    public int findLatestVersionNo(long formId) {
        Integer version = jdbc.queryForObject(
                "SELECT COALESCE(MAX(version_no), 0) FROM rule_set_versions WHERE form_id = ?",
                Integer.class,
                formId
        );
        return version == null ? 0 : version;
    }

    public long insertDraftRuleSet(long formId, int versionNo, Long createdBy) {
        return jdbc.queryForObject(
                """
                INSERT INTO rule_set_versions (form_id, version_no, status, created_by)
                VALUES (?, ?, 'DRAFT', ?)
                RETURNING id
                """,
                Long.class,
                formId,
                versionNo,
                createdBy
        );
    }

    public long insertRule(
            long formId,
            long ruleSetVersionId,
            String ruleCode,
            long questionId,
            String ruleTypeCode,
            String paramsJson,
            String onFail,
            String onMissing
    ) {
        return jdbc.queryForObject(
                """
                INSERT INTO rules (
                    form_id, rule_set_version_id, rule_code, question_id, rule_type_code, params, on_fail, on_missing
                )
                VALUES (?, ?, ?, ?, ?, CAST(? AS jsonb), ?, ?)
                RETURNING id
                """,
                Long.class,
                formId,
                ruleSetVersionId,
                ruleCode,
                questionId,
                ruleTypeCode,
                paramsJson,
                onFail,
                onMissing
        );
    }

    public List<RuleResponse> findDraftRulesForForm(long formId) {
        return jdbc.query(
                """
                SELECT r.id, r.form_id, r.rule_set_version_id, r.rule_code, r.question_id,
                       q.question_key, r.rule_type_code, r.params::text AS params,
                       r.on_fail, r.on_missing, rsv.version_no
                FROM rules r
                JOIN rule_set_versions rsv ON rsv.id = r.rule_set_version_id
                JOIN questions q ON q.id = r.question_id
                WHERE r.form_id = ?
                  AND rsv.status = 'DRAFT'
                  AND rsv.version_no = (
                      SELECT MAX(current_version.version_no)
                      FROM rule_set_versions current_version
                      WHERE current_version.form_id = ? AND current_version.status = 'DRAFT'
                  )
                ORDER BY r.rule_code
                """,
                (resultSet, rowNum) -> {
                    try {
                        return new RuleResponse(
                                resultSet.getLong("id"),
                                resultSet.getLong("form_id"),
                                resultSet.getLong("rule_set_version_id"),
                                resultSet.getInt("version_no"),
                                resultSet.getString("rule_code"),
                                resultSet.getLong("question_id"),
                                resultSet.getString("question_key"),
                                resultSet.getString("rule_type_code"),
                                objectMapper.readTree(resultSet.getString("params")),
                                resultSet.getString("on_fail"),
                                resultSet.getString("on_missing")
                        );
                    } catch (JsonProcessingException exception) {
                        throw new IllegalStateException("Invalid JSON stored in rule params", exception);
                    }
                },
                formId,
                formId
        );
    }
}
