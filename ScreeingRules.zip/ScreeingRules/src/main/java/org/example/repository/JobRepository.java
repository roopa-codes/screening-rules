package org.example.repository;

import org.example.model.JobResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JobRepository {
    private final JdbcTemplate jdbc;

    public JobRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public boolean formExists(long formId) {
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM forms WHERE id = ?",
                Integer.class,
                formId
        );
        return count != null && count > 0;
    }

    public JobResponse insert(String title, long formId, Long createdBy) {
        return jdbc.queryForObject(
                """
                INSERT INTO jobs (title, form_id, created_by)
                VALUES (?, ?, ?)
                RETURNING id, title, form_id, status
                """,
                (resultSet, rowNum) -> new JobResponse(
                        resultSet.getLong("id"),
                        resultSet.getString("title"),
                        resultSet.getLong("form_id"),
                        resultSet.getString("status")
                ),
                title,
                formId,
                createdBy
        );
    }
}
