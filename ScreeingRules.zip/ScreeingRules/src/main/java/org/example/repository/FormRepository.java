package org.example.repository;

import org.example.model.QuestionRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class FormRepository {
    private static final RowMapper<QuestionRecord> QUESTION_ROW_MAPPER = (resultSet, rowNum) ->
            new QuestionRecord(
                    resultSet.getLong("id"),
                    resultSet.getString("question_key"),
                    resultSet.getString("label"),
                    resultSet.getString("answer_type"),
                    resultSet.getString("options")
            );

    private final JdbcTemplate jdbc;

    public FormRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public long insertForm(String name) {
        return jdbc.queryForObject("INSERT INTO forms (name) VALUES (?) RETURNING id", Long.class, name);
    }

    public void insertQuestionIfMissing(String questionKey, String label, String answerType, String optionsJson) {
        jdbc.update(
                """
                INSERT INTO questions (question_key, label, answer_type, options)
                VALUES (?, ?, ?, CAST(? AS jsonb))
                ON CONFLICT (question_key) DO NOTHING
                """,
                questionKey,
                label,
                answerType,
                optionsJson
        );
    }

    public QuestionRecord findQuestionByKey(String questionKey) {
        return jdbc.queryForObject(
                """
                SELECT id, question_key, label, answer_type, options::text AS options
                FROM questions
                WHERE question_key = ?
                """,
                QUESTION_ROW_MAPPER,
                questionKey
        );
    }

    public void linkQuestionToForm(long formId, long questionId, int displayOrder, boolean required) {
        jdbc.update(
                """
                INSERT INTO form_questions (form_id, question_id, display_order, is_required)
                VALUES (?, ?, ?, ?)
                """,
                formId,
                questionId,
                displayOrder,
                required
        );
    }

    public void insertAudit(String action, String entityType, long entityId, String afterJson) {
        jdbc.update(
                """
                INSERT INTO audit_logs (action, entity_type, entity_id, before_data, after_data)
                VALUES (?, ?, ?, NULL, CAST(? AS jsonb))
                """,
                action,
                entityType,
                entityId,
                afterJson
        );
    }
}
