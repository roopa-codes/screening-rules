package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScreeningRulesApplication {
    public static void main(String[] args) {
        SpringApplication.run(ScreeningRulesApplication.class, args);
    }
}
