package org.example.model;

import com.fasterxml.jackson.databind.JsonNode;

public record FormQuestionResponse(
        long questionId,
        String questionKey,
        String label,
        String answerType,
        boolean required,
        JsonNode options,
        int displayOrder
) {
}
