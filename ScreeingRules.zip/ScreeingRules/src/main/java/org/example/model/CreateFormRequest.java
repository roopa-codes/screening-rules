package org.example.model;

import java.util.List;

public record CreateFormRequest(String name, List<FormQuestionRequest> questions) {
}
