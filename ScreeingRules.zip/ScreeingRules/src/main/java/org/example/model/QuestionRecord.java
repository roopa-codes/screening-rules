package org.example.model;

public record QuestionRecord(
        long id,
        String questionKey,
        String label,
        String answerType,
        String optionsJson
) {
}
