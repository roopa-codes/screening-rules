package org.example.model;

import com.fasterxml.jackson.databind.JsonNode;

public record CreateRuleRequest(
        String ruleCode,
        String questionKey,
        String ruleTypeCode,
        JsonNode params,
        String onFail,
        String onMissing,
        Long createdBy
) {
}
