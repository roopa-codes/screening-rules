package org.example.model;

import com.fasterxml.jackson.databind.JsonNode;

public record RuleResponse(
        long id,
        long formId,
        long ruleSetVersionId,
        int versionNo,
        String ruleCode,
        long questionId,
        String questionKey,
        String ruleTypeCode,
        JsonNode params,
        String onFail,
        String onMissing
) {
}
