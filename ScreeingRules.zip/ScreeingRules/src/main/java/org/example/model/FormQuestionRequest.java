package org.example.model;

import com.fasterxml.jackson.databind.JsonNode;

public record FormQuestionRequest(
        String questionKey,
        String label,
        String answerType,
        boolean required,
        JsonNode options
) {
}
