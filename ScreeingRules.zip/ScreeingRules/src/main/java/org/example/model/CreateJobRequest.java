package org.example.model;

public record CreateJobRequest(String title, long formId, Long createdBy) {
}
