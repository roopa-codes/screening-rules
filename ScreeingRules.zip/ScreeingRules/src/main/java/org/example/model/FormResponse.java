package org.example.model;

import java.util.List;

public record FormResponse(long id, String name, List<FormQuestionResponse> questions) {
}
