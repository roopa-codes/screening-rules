package org.example.model;

public record RuleSetVersionRecord(long id, int versionNo) {
}
