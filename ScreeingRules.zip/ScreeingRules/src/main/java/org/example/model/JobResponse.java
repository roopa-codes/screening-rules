package org.example.model;

public record JobResponse(long id, String title, long formId, String status) {
}
