package org.example.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.exception.ConflictException;
import org.example.exception.InvalidRequestException;
import org.example.model.CreateFormRequest;
import org.example.model.FormQuestionRequest;
import org.example.model.FormQuestionResponse;
import org.example.model.FormResponse;
import org.example.model.QuestionRecord;
import org.example.repository.FormRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class FormService {
    private static final String DEFAULT_OPTIONS = "[]";

    private final FormRepository formRepository;
    private final ObjectMapper objectMapper;

    public FormService(FormRepository formRepository, ObjectMapper objectMapper) {
        this.formRepository = formRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public FormResponse createForm(CreateFormRequest request) {
        if (request == null || isBlank(request.name())) {
            throw new InvalidRequestException("name is required");
        }
        if (request.questions() == null || request.questions().isEmpty()) {
            throw new InvalidRequestException("questions must contain at least one question");
        }

        validateQuestions(request.questions());
        String formName = request.name().trim();
        long formId = formRepository.insertForm(formName);
        List<FormQuestionResponse> questions = new ArrayList<>();

        for (int i = 0; i < request.questions().size(); i++) {
            FormQuestionRequest question = request.questions().get(i);
            String questionKey = question.questionKey().trim();
            String label = question.label().trim();
            String answerType = question.answerType().trim().toUpperCase();
            String optionsJson = serializeOptions(question.options());
            formRepository.insertQuestionIfMissing(questionKey, label, answerType, optionsJson);

            QuestionRecord stored = formRepository.findQuestionByKey(questionKey);
            ensureQuestionDefinitionMatches(stored, label, answerType, optionsJson, questionKey);
            int displayOrder = i + 1;
            try {
                formRepository.linkQuestionToForm(formId, stored.id(), displayOrder, question.required());
            } catch (DuplicateKeyException exception) {
                throw new ConflictException("question is already linked to this form: " + questionKey);
            }
            questions.add(toResponse(stored, question.required(), displayOrder));
        }

        FormResponse response = new FormResponse(formId, formName, questions);
        formRepository.insertAudit("FORM_CREATED", "FORM", formId, serialize(objectMapper.valueToTree(response)));
        return response;
    }

    private void validateQuestions(List<FormQuestionRequest> questions) {
        List<String> keys = new ArrayList<>();
        for (FormQuestionRequest question : questions) {
            if (question == null || isBlank(question.questionKey()) || isBlank(question.label())
                    || isBlank(question.answerType())) {
                throw new InvalidRequestException("each question requires questionKey, label, and answerType");
            }
            String key = question.questionKey().trim();
            if (keys.contains(key)) {
                throw new InvalidRequestException("duplicate questionKey in form: " + key);
            }
            keys.add(key);
            if (question.options() != null && !question.options().isNull()
                    && !question.options().isArray() && !question.options().isObject()) {
                throw new InvalidRequestException("options must be a JSON array or object");
            }
        }
    }

    private void ensureQuestionDefinitionMatches(
            QuestionRecord stored,
            String label,
            String answerType,
            String requestedOptions,
            String questionKey
    ) {
        JsonNode storedOptions = parseJson(stored.optionsJson() == null ? DEFAULT_OPTIONS : stored.optionsJson());
        JsonNode expectedOptions = parseJson(requestedOptions);
        if (!stored.label().equals(label)
                || !stored.answerType().equalsIgnoreCase(answerType)
                || !storedOptions.equals(expectedOptions)) {
            throw new ConflictException("questionKey already exists with a different definition: " + questionKey);
        }
    }

    private FormQuestionResponse toResponse(QuestionRecord stored, boolean required, int displayOrder) {
        return new FormQuestionResponse(
                stored.id(),
                stored.questionKey(),
                stored.label(),
                stored.answerType(),
                required,
                parseJson(stored.optionsJson() == null ? DEFAULT_OPTIONS : stored.optionsJson()),
                displayOrder
        );
    }

    private String serializeOptions(JsonNode options) {
        return options == null || options.isNull() ? DEFAULT_OPTIONS : serialize(options);
    }

    private String serialize(JsonNode value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw new InvalidRequestException("JSON value could not be serialized");
        }
    }

    private JsonNode parseJson(String value) {
        try {
            return objectMapper.readTree(value);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Invalid JSON stored in the database", exception);
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
