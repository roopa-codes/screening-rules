package org.example.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.exception.ConflictException;
import org.example.exception.InvalidRequestException;
import org.example.exception.ResourceNotFoundException;
import org.example.model.CreateRuleRequest;
import org.example.model.RuleResponse;
import org.example.model.RuleSetVersionRecord;
import org.example.repository.FormRepository;
import org.example.repository.RuleRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RuleService {
    private static final String DEFAULT_MISSING_OUTCOME = "REVIEW";

    private final RuleRepository ruleRepository;
    private final FormRepository formRepository;
    private final ObjectMapper objectMapper;

    public RuleService(
            RuleRepository ruleRepository,
            FormRepository formRepository,
            ObjectMapper objectMapper
    ) {
        this.ruleRepository = ruleRepository;
        this.formRepository = formRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public RuleResponse createRule(long formId, CreateRuleRequest request) {
        if (request == null) {
            throw new InvalidRequestException("request body is required");
        }
        requireText(request.ruleCode(), "ruleCode");
        requireText(request.questionKey(), "questionKey");
        requireText(request.ruleTypeCode(), "ruleTypeCode");
        requireText(request.onFail(), "onFail");
        if (request.params() == null || request.params().isNull()) {
            throw new InvalidRequestException("params is required");
        }
        String ruleCode = request.ruleCode().trim();
        String questionKey = request.questionKey().trim();
        String ruleTypeCode = request.ruleTypeCode().trim();
        String onFail = normalizeOutcome(request.onFail(), "onFail");
        String onMissing = request.onMissing() == null || request.onMissing().isBlank()
                ? DEFAULT_MISSING_OUTCOME
                : normalizeOutcome(request.onMissing(), "onMissing");

        if (!ruleRepository.lockForm(formId)) {
            throw new ResourceNotFoundException("form not found: " + formId);
        }
        Long questionId = ruleRepository.findQuestionIdOnForm(formId, questionKey);
        if (questionId == null) {
            throw new InvalidRequestException("questionKey is not part of this form");
        }
        if (!ruleRepository.ruleTypeExists(ruleTypeCode)) {
            throw new InvalidRequestException("unknown ruleTypeCode: " + ruleTypeCode);
        }

        RuleSetVersionRecord ruleSet = findOrCreateDraftRuleSet(formId, request.createdBy());
        long ruleId;
        try {
            ruleId = ruleRepository.insertRule(
                    formId,
                    ruleSet.id(),
                    ruleCode,
                    questionId,
                    ruleTypeCode,
                    serialize(request.params()),
                    onFail,
                    onMissing
            );
        } catch (DuplicateKeyException exception) {
            throw new ConflictException(
                    "ruleCode already exists in draft rule-set version " + ruleSet.versionNo()
            );
        }

        RuleResponse response = new RuleResponse(
                ruleId,
                formId,
                ruleSet.id(),
                ruleSet.versionNo(),
                ruleCode,
                questionId,
                questionKey,
                ruleTypeCode,
                request.params().deepCopy(),
                onFail,
                onMissing
        );
        formRepository.insertAudit("RULE_CREATED", "RULE", ruleId, serialize(objectMapper.valueToTree(response)));
        return response;
    }

    public java.util.List<RuleResponse> listRules(long formId) {
        if (!ruleRepository.lockForm(formId)) {
            throw new ResourceNotFoundException("form not found: " + formId);
        }
        return ruleRepository.findDraftRulesForForm(formId);
    }

    private RuleSetVersionRecord findOrCreateDraftRuleSet(long formId, Long createdBy) {
        RuleSetVersionRecord existing = ruleRepository.findDraftRuleSet(formId);
        if (existing != null) {
            return existing;
        }

        int versionNo = ruleRepository.findLatestVersionNo(formId) + 1;
        long id = ruleRepository.insertDraftRuleSet(formId, versionNo, createdBy);
        RuleSetVersionRecord created = new RuleSetVersionRecord(id, versionNo);
        formRepository.insertAudit(
                "RULE_SET_VERSION_CREATED",
                "RULE_SET_VERSION",
                id,
                serialize(objectMapper.valueToTree(created))
        );
        return created;
    }

    private String serialize(JsonNode value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw new InvalidRequestException("JSON value could not be serialized");
        }
    }

    private String normalizeOutcome(String outcome, String fieldName) {
        String normalized = outcome.trim().toUpperCase();
        if (!normalized.equals("FAIL") && !normalized.equals("REVIEW")) {
            throw new InvalidRequestException(fieldName + " must be FAIL or REVIEW");
        }
        return normalized;
    }

    private void requireText(String value, String name) {
        if (value == null || value.isBlank()) {
            throw new InvalidRequestException(name + " is required");
        }
    }
}
