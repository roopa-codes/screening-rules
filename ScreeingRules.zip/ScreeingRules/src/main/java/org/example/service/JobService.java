package org.example.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.exception.InvalidRequestException;
import org.example.exception.ResourceNotFoundException;
import org.example.model.CreateJobRequest;
import org.example.model.JobResponse;
import org.example.repository.FormRepository;
import org.example.repository.JobRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class JobService {
    private final JobRepository jobRepository;
    private final FormRepository formRepository;
    private final ObjectMapper objectMapper;

    public JobService(
            JobRepository jobRepository,
            FormRepository formRepository,
            ObjectMapper objectMapper
    ) {
        this.jobRepository = jobRepository;
        this.formRepository = formRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public JobResponse createJob(CreateJobRequest request) {
        if (request == null || request.title() == null || request.title().isBlank()) {
            throw new InvalidRequestException("title is required");
        }
        if (!jobRepository.formExists(request.formId())) {
            throw new ResourceNotFoundException("form not found: " + request.formId());
        }

        JobResponse job = jobRepository.insert(request.title().trim(), request.formId(), request.createdBy());
        try {
            formRepository.insertAudit(
                    "JOB_CREATED",
                    "JOB",
                    job.id(),
                    objectMapper.writeValueAsString(job)
            );
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Could not serialize job audit data", exception);
        }
        return job;
    }
}
